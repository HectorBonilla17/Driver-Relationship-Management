package com.bonilla.DriverRM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DriverRmApplication {

	public static void main(String[] args) {
		SpringApplication.run(DriverRmApplication.class, args);
	}

}
