package com.bonilla.DriverRM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DriverRmApplicationTests {

	@Test
	void contextLoads() {
	}

}
